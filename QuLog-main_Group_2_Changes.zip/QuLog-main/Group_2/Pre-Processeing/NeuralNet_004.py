import copy
from collections import Counter
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.model_selection import KFold, StratifiedKFold
import pandas as pd
import matplotlib.pyplot as plt
from torch import optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
import re
import numpy as np
from sklearn import metrics
from sklearn.model_selection import StratifiedKFold
from imblearn.over_sampling import SMOTE

sm = SMOTE(random_state = 41)
from spacy.tokens import Doc

import spacy
nlp = spacy.load("en_core_web_sm")

kf = KFold(n_splits= 5, shuffle=True, random_state=41)

'''
A method to pad or truncate the numeric parts of speach tags to the correct length for the neural network
'''
def max_len(df):
    length = 5

    #print(df.iloc[0, 5])
    for i in range(len(df)):
        while len(df.iloc[i, 5]) < length:
            df.iloc[i, 5].append(np.int64(0))
        df.iat[i,5] = df.iloc[i, 5][:length]

        #print(df.iloc[i, 5])
        #print('------------------')

'''
A class to represent the neural network

class Model(nn.Module):

    Constructor for neural network.


    def __init__(self, in_features, h1, h2, out_features = 3):
        super().__init__()
        self.in_features = in_features
        self.h1 = h1
        self.h2 = h2


        self.fc1 = nn.Linear(in_features, h1)
        self.fc2 = nn.Linear(h1, h2)
        self.out = nn.Linear(h2, out_features)


    
    A method to move the neural network layer forward.
    def forward(self, x):
        x = F.softmax(self.fc1(x))
        x = F.softmax(self.fc2(x))

        x = self.out(x)

        return x

Creates parts of speach tags
'''
def Pos(txt):
    txt = re.sub('[^a-zA-Z0-9_]', ' ', txt)
    txt = re.sub(' +', ' ', txt)
    doc = nlp(txt)
    partOfSpeech = []
    for token in doc:
        partOfSpeech.append(token.pos_)

    return partOfSpeech

'''
Converts Tokens into numeric parts of speach tags
'''
def PosNum(txt):
    txt = re.sub('[^a-zA-Z0-9_]', ' ', txt)
    txt = re.sub(' +', ' ', txt)
    doc = nlp(txt)
    partOfSpeech = []
    for token in doc:
        partOfSpeech.append(np.int64(token.pos))

    return partOfSpeech


'''
Performs processing steps
'''
def preprocess(df):

    #Creates a column for tokenized log messages
    df['tokens'] = df['static_text'].apply(tokens)
    #Creates a column for parts of speach
    df['pos'] = df['static_text'].apply(Pos)
    #Creats a column for numeric parts of speach tags
    df['posNum'] = df['static_text'].apply(PosNum)

    return df

'''
Tokenizes the log messages
'''
def tokens(txt):

    txt = re.sub('[^a-zA-Z0-9_]', ' ', txt)
    txt = re.sub(' +', ' ', txt)
    doc = nlp(txt)

    tokens = []

    for token in doc:
        tokens.append(token)

    return tokens


class EarlyStopping:


    def __init__(self, patience = 5, min_delta=0, restore_best_weights= True):
        self.patience = patience
        self.min_delta = min_delta
        self.restore_best_weights = restore_best_weights
        self.best_model = None
        self.best_loss = None
        self.counter = 0
        self.status = ""

    def __call__(self, model, val_loss):
        if self.best_loss is None:
            self.best_loss = val_loss
            self.best_model = copy.deepcopy(model.state_dict())
        elif self.best_loss - val_loss >= self.min_delta:
            self.best_model = copy.deepcopy(model.state_dict())
            self.best_loss = val_loss
            self.counter =0
            self.status = f"Improvement found, counter reset to {self.counter}"
        else:
            self.counter+=1
            self.status = f"Improvement found in the last {self.counter} epochs"
            if self.count >= self.patience:
                self.status = f"Early stopping triggered after {self.counter} epochs"
                if self.restore_best_weights:
                    model.load_state_dict(self.best_model)
                return True
        return False

    def getStatus(self):
        return self.status
#Takes in the nine_systems data provided by the QuLog Project and splits it into training and test data.



df = pd.read_csv('C:/Course_work/DSCI_644/Project/QuLog-main/Group_2/Data_In/nine_systems_data.csv')


df = df.drop(df[(df.log_level != "info") & (df.log_level != "warn") & (df.log_level != "error")].index)


#print(Counter(df['log_level']))
#Pre-processing

df = preprocess(df)



torch.manual_seed(41)



#Creates numeric values for classifications
df['log_level_num'] = df['log_level'].replace('info', np.int64(0.0)).replace('error', np.int64(1.0)).replace('warn', np.int64(2.0))

max_len(df)


X = np.ndarray(shape=(len(df),5))
for i in X:
    print(i)
#Creates numpy array for X(input) values


print(X.shape)
print(len(df))
print('-----------------------------')
for i in range(X.shape[0]):
    list = df.iloc[i,5]
    #print(i)
    print(list)
    for k in range(len(list)-1):
        print(list[k])
        X[i, k] = list[k]


y = np.ndarray(shape=(len(df)))

#Creates numpy array for X(input) values
#print(df.iloc[0])

#print(X.shape)
#print(len(df))
#print('-----------------------------')
for i in range(len(df)):
    #print(df.iloc[i,6])
    y[i] = df.iloc[i,6]



y = df['log_level_num']
y = y.values

X, y = SMOTE(random_state=41).fit_resample(X,y)


x = torch.tensor(X, dtype=torch.double)


y = torch.tensor(y, dtype=torch.double)

model = nn.Sequential(nn.Linear(x.shape[1], 5), nn.ReLU(), nn.Linear(25, y.shape[0]), nn.Softmax(dim=1))

kf = StratifiedKFold(5, shuffle=True, random_state = 41)

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters())

oos_y = []
oos_pred = []
fold = 0

for train, test in kf.split(x, y):
    fold +=1
    print(f"Fold {fold}")

    x_train = torch.tensor(x[train], dtype= torch.float32)
    y_train = torch.tensor(y[train], dtype= torch.float32)
    x_test = torch.tensor(x[test], dtype= torch.float32)
    y_test = torch.tensor(y[test], dtype= torch.float32)

    EPOCHS = 500
    epoch = 0
    done = False
    es = EarlyStopping(restore_best_weights=True)

    while not done and epoch < EPOCHS:
        epoch+=1
        model.train()
        optimizer.zero_grad()
        output = model(x_train)
        loss = criterion(output, y_train)
        loss.backward()
        optimizer.step()

        model.eval()
        with torch.no_grad():
            y_val = model(x_test)
            val_loss = criterion(y_val, y_test)


            if es(model, val_loss):
                done=True


        with torch.no_grad():
            y_val = model(x_test)
            _, pred = torch.max(y_val, 1)


        oos_y.append(y_test.cpu().numpy())
        oos_pred.append(pred.cpu().numpy())

        print(f"Epoch {epoch}/{EPOCHS}, Validation Loss: {val_loss.item()}, {es.status}")

        score = metrics.accuracy_score(y_test.cpu().numpy(), pred.cpu().numpy())

    oos_y = np.concatenate(oos_y)
    oos_pred = np.concatenate(oos_pred)

    precision = metrics.accuracy_score(oos_y, oos_pred)
    f1 = metrics.f1_score(oos_y, oos_pred)
    recall = metrics.recall_score(oos_y, oos_pred)
    print(f"Precision: {precision}")
    print(f"Recall: {recall}")
    print(f"F1: {f1}")