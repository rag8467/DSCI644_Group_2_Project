    |code 
    |--- level_quality
    |------ qulog_attention_nn_type1
    |------ qulog_svc
    |------ level_qulog_sm_rf
    |--- ling_quality
    |------ qulog_attention_nn_type1
    |------ qulog_rf
    |------ qulog_sm_svc
    |--- training_scirpts
    |------ level
    |--------- qulog_svc
    |--------- qulog_sm_rf
    |--------- qulog_attention
    |------ ling
    |--------- qulog_svc
    |--------- qulog_sm_rf
    |--------- qulog_attention
    |data 
    |--- github_repos_data
    |--- linguistic_quality_inter.csv
    |--- nine_systems_data.csv
    |--- stars_repos.csv
    |requirments.txt
    |README.md
